﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace azureapp_swar.Pages;

public class PrivacyModel : PageModel
{
    public void OnGet()
    {
    }
}

