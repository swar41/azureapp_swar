using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace azureapp_swar.Pages;

public class IndexModel : PageModel
{
    public void OnGet()
    {

    }
}
